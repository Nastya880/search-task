export type AddressType = {
    city: string;
}
