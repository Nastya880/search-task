import { UserType } from "./UserType";

export type SearchContextType = {
    users: UserType[];
};
